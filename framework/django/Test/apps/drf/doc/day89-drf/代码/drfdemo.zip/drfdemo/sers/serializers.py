from rest_framework import serializers
from stuapi.models import Student
"""
rest_framework.serializers 是drf提供给开发者调用的序列化器模块
里面声明了所有的可用序列化器的基类，常用的有：
Serializer      序列化器基类，drf中所有的序列化器类都必须继承于 Serializer
ModelSerializer 模型序列化器基类，是序列化器基类Serializer的子类，在工作中，除了Serializer基类以外，最常用的序列化器类基类
"""

def check_desc(data):
    """
    验证函数，通过字段声明的validators选项中作为列表成员传递使用
    data: 当前要校验的字段的值
    """
    if "hi" in data:
        raise serializers.ValidationError(detail="个性签名中不能出现废话！", code="validators")
    # 验证代码的最后，必须把本地校验的数据作为返回值返回给外界，否则serializer序列化器对象会丢失验证的数据
    return data


class StudentSerializer(serializers.Serializer):
    """学生信息序列化器"""
    # 1. 转换的字段声明
    id = serializers.IntegerField(read_only=True)  # 在序列化阶段使用，在反序列化阶段中被忽视掉
    age = serializers.IntegerField(min_value=1, max_value=100, error_messages={
        "min_value": "年龄太小了，必须大于或等于{min_value}",
        "max_value": "年龄太大了，必须小于或等于{max_value}",
    })
    name = serializers.CharField(max_length=12, min_length=4, error_messages={
        # 字段选项在反序列化阶段中校验字段如果失败的错误提示
        # "选项名": "提示内容",
        "min_length": "name字段的值必须至少{min_length}个字符",
        "max_length": "name字段的值必须低于{max_length}个字符",
        "required": "name字段是必填字段",
    })
    classmate = serializers.CharField()
    sex = serializers.BooleanField(default=True)  # default=True 等价于设置当前字段为选填字段，默认值为True
    description = serializers.CharField(validators=[check_desc])  # validators=[验证函数名, 验证函数名....]
    password = serializers.CharField(write_only=True)  # 用户密码
    re_password = serializers.CharField(write_only=True)  # 确认密码

    # 2. 如果当前序列化器继承的是ModelSerializer，则需要声明调用的模型信息
    # class Meta:
    #     model = 模型
    #     fields = "__all__"
    #     fields = ["字段1","字段2",....]

    # 3. 验证代码的对象方法
    """同时校验多个字段的方法"""
    def validate(self, attrs): # 方法名validate是固定的，attrs就是客户端发送的数据，字典格式
        if attrs["password"] != attrs["re_password"]:
            raise serializers.ValidationError(detail="对不起，密码与确认密码不一致！请重新填写", code="validate")
        # 验证代码的最后，必须把本地校验的数据作为返回值返回给外界，否则serializer序列化器对象会丢失验证的数据
        # 返回的验证数据如果被修改了，则会覆盖客户端提交的数据
        # attrs["description"] = "hello!!!!"
        return attrs

    """校验指定字段数据的方法"""
    def validate_name(self, data):  # 方法名的格式必须以 validate_<字段名> 为名称，否则序列化器不识别！
        if data == "root":
            raise serializers.ValidationError(detail=f"name字段的值不能是{data}", code="validate")
            print("一旦出现异常，序列化器将返回异常给调用处，不会继续往下执行")
        # 验证代码的最后，必须把本地校验的数据作为返回值返回给外界，否则serializer序列化器对象会丢失验证的数据
        return data

    # 4. 模型操作的扩展方法
    def create(self, validated_data):  # 添加数据操作，添加数据以后，就自动实现了从字典变成模型对象的过程
        """
        添加操作
        validated_data：经过验证后的客户端数据
        """
        student = Student.objects.create(
            name=validated_data.get("name"),
            age=validated_data.get("age"),
            sex=validated_data.get("sex"),
            classmate=validated_data.get("classmate"),
            description=validated_data.get("description")
        )

        # 注意，可以把新增的模型对象作为返回值返给serializer.save()
        return student

    def update(self, instance, validated_data): # 更新数据操作，更新数据以后，就自动实现了从字典变成模型对象的过程
        """更新数据"""
        if validated_data.get('name'):
            instance.name = validated_data.get('name')
        if validated_data.get('age'):
            instance.age = validated_data.get('age')
        if validated_data.get('sex', None) is not None:
            instance.sex = validated_data.get('sex')
        if validated_data.get('classmate'):
            instance.classmate = validated_data.get('classmate')
        if validated_data.get('description'):
            instance.description = validated_data.get('description')

        instance.save()

        return instance


class StudentModelSerializer(serializers.ModelSerializer):
    """学生信息模型类序列化器"""
    # 字段声明中可以覆盖从模型那边导入的字段声明[没有必要重写，只需要extra_kwargs中补充验证选项即可]
    # age = serializers.IntegerField(min_value=10)

    # 同时，也可以声明一些模型中没有的字段
    password = serializers.CharField(write_only=True)
    re_password = serializers.CharField(write_only=True)

    class Meta:
        model = Student  # 必填
        # 务必把模型导入过的字段与上面的字段全部填入到fields的属性值，否则报错！！
        fields = ["id", "name", "age", "sex", "classmate", "password", "re_password"]
        # fields = "__all__" # 从模型中引入所有的字段序列化器中
        # exclude = ["description", "sex"]
        read_only_fields = ["id", "sex"]  # 只读字段列表，设置在这里的字段只会在序列化时使用到，不会被用于反序列化
        extra_kwargs = {
            "age": {"min_value": 10, "max_value": 100},
            "name": {"min_length": 4, "max_length": 16, "error_messages": {
                "min_length": "name字段的值长度必须是4个字符以上"
            }},
        }

    def validate(self, attrs):
        """验证多个字段"""
        if attrs["password"] != attrs["re_password"]:
            raise serializers.ValidationError(detail="密码和确认密码不一致")

        # 可以在验证完成以后，把数据库中不需要的字典从attrs中移除
        attrs.pop("password")
        attrs.pop("re_password")

        # 务必把验证后的内容返回给客户端
        return attrs
