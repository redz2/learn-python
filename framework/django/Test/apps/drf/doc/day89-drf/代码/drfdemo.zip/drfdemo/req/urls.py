from django.urls import path
from . import views
urlpatterns = [
    path("s1", views.StudentView.as_view()),  # django
    path("s2", views.StudentAPIView.as_view()), # drf
]