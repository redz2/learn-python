import json
from django.views import View
from django.http.response import JsonResponse
from .models import Student
# Create your views here.

"""
POST /students/   添加一个学生信息
GET  /students/   获取所有学生信息

GET    /students/<pk>/  获取一个学生信息
PUT    /students/<pk>/  更新一个学生信息
DELETE /students/<pk>/  删除一个学生信息

一个路由对应一个视图类，所以我们可以把5个API分成2个类来完成
"""


class StudentView(View):
    def get(self, request):
        """获取所有学生信息"""
        student_list = Student.objects.values()
        return JsonResponse(list(student_list), safe=False)

    def post(self, request):
        """添加一个学生信息"""
        # 接收客户端数据，并校验
        try:
            data = json.loads(request.body)
        except Exception:
            return JsonResponse({"error": "提交数据错误！"}, status=400)
        try:
            # 操作数据模型
            student = Student.objects.create(
                name=data.get("name"),
                sex=data.get("sex"),
                age=data.get("age"),
                classmate=data.get("classmate"),
                description=data.get("description"),
            )
            # 返回响应结果
            return JsonResponse({
                "id": student.id,
                "name": student.name,
                "sex": student.sex,
                "age": student.age,
                "classmate": student.classmate,
                "description": student.description,
            }, status=201, safe=False)
        except Exception as e:
            return JsonResponse({"error": f"添加学生信息有误: {e}"}, status=500)


class StudentInfoView(View):
    def get(self, request, pk):
        """获取一个学生信息"""
        try:
            student = Student.objects.get(pk=pk)
            return JsonResponse({
                "id": student.id,
                "name": student.name,
                "sex": student.sex,
                "age": student.age,
                "classmate": student.classmate,
                "description": student.description,
            })
        except Student.DoesNotExist:
            return JsonResponse({"error": "当前学生ID不存在！"}, status=400)

    def put(self, request, pk):
        """修改一个学生信息"""
        try:
            student = Student.objects.get(pk=pk)
        except Student.DoesNotExist:
            return JsonResponse({"error": "当前学生ID不存在！"}, status=400)

        try:
            data = json.loads(request.body)

            if data.get("name"):
                student.name = data.get("name")
            if data.get("age"):
                student.age = data.get("age")
            if data.get("sex"):
                student.sex = data.get("sex")
            if data.get("classmate"):
                student.classmate = data.get("classmate")
            if data.get("description"):
                student.description = data.get("description")
            student.save()

            return JsonResponse({
                "id": student.id,
                "name": student.name,
                "sex": student.sex,
                "age": student.age,
                "classmate": student.classmate,
                "description": student.description,
            }, status=201, safe=False)

        except Exception as e:
            return JsonResponse({"error": f"提交数据错误：{e}"}, status=400)

    def delete(self, request, pk):
        """删除一个学生信息"""
        Student.objects.filter(pk=pk).delete()
        return JsonResponse({}, status=204)
