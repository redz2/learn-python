from django.views import View
from .serializers import StudentSerializer, StudentModelSerializer
from stuapi.models import Student
from django.http.response import JsonResponse


# Create your views here.
class Student1View(View):
    def get1(self, request):
        """序列化器的基本使用：序列化单个模型对象为字典"""
        student = Student.objects.first()
        print(student)
        # 把模型对象作为instance参数的值传递到序列化器中进行转换数据格式
        serializer = StudentSerializer(instance=student)
        print(serializer.data)
        """
        {'id': 1, 'name': 'xiaoming', 'sex': True, 'age': 16, 'description': 'xxxxx'}
        """
        return JsonResponse(serializer.data)

    def get2(self, request):
        """序列化器的基本使用：序列化多个模型对象为列表"""
        student_list = Student.objects.all()
        print(student_list)
        # 把模型列表作为instance参数传递到序列化器中进行数据格式转换
        serializer = StudentSerializer(student_list, many=True)
        print(serializer.data)
        return JsonResponse(serializer.data, safe=False)

    def get3(self, request):
        """序列化器的基本使用：反序列化验证数据"""
        # 模拟客户端提交过来的数据
        data = {
            "age": -20,
            "name": "root",
            # "name": "xiaoming",
            "classmate": 303,
            "description": "hi hello world",
            "password": "123",
            "re_password": "456",
        }

        # 实例化序列化器用于反序列化
        serializer = StudentSerializer(data=data)
        # # 验证失败不会抛出异常
        # ret = serializer.is_valid()
        # if ret:
        #     print("验证通过！")
        #     print(serializer.validated_data) # 获取验证通过后的客户端提交的数据
        # else:
        #     print("验证失败！获取验证错误的提示信息")
        #     print(serializer.errors)
        #     print(serializer.error_messages)

        # 验证失败则会抛出异常[最常用]
        serializer.is_valid(raise_exception=True)
        print("验证通过，验证结果数据：", serializer.validated_data)
        return JsonResponse("ok", safe=False)

    def get4(self, request):
        """序列化器的基本使用：自动调用create添加数据"""
        # 模拟客户端提交过来的数据
        data = {
            "name": "xiaoming",
            "age": 20,
            "classmate": 303,
            "description": "hello world",
            "password": "456",
            "re_password": "456",
        }

        serializer = StudentSerializer(data=data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        # save源代码中，根据实例化序列化器时是否传递了instance，
        # 如果传递了instance参数，则serializer.save()会自动调用序列化器内部的update,并把instance与验证后的validated_data作为参数
        # 如果没有传递instance参数，则serializer.save()会自动调用序列化器内部的create方法，并把验证后的validated_data作为参数

        # 使用serializer.data实现序列化操作
        return JsonResponse(serializer.data, status=201, safe=False)

    def get5(self, request):
        """序列化器的基本使用：自动调用update修改数据"""
        # 模拟客户端提交过来的数据
        data = {
            "name": "小明同学",
            "classmate": 305,
            "description": "hello world",
            "password": "456",
            "re_password": "456",
        }

        # 查询数据库，得到要修改的模型对象
        student = Student.objects.get(pk=9)

        # partial=True 表示 对不存在的数据或客户端没有提供的数据，不需要按序列化器的字段列表进行验证。
        serializer = StudentSerializer(instance=student, data=data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save(sex=False)
        # save源代码中，根据实例化序列化器时是否传递了instance，
        # 如果传递了instance参数，则serializer.save()会自动调用序列化器内部的update,并把instance与验证后的validated_data作为参数
        # 如果没有传递instance参数，则serializer.save()会自动调用序列化器内部的create方法，并把验证后的validated_data作为参数

        # 使用serializer.data实现序列化操作
        return JsonResponse(serializer.data, status=201, safe=False)

    def get6(self,request):
        """模型类序列化器的基本使用：序列化1个模型"""
        student = Student.objects.first()
        serializer = StudentModelSerializer(instance=student)
        print(serializer)
        return JsonResponse(serializer.data)


    def get7(self,request):
        """模型类序列化器的基本使用：序列化多个模型"""
        student_list = Student.objects.all()
        serializer = StudentModelSerializer(instance=student_list, many=True)
        return JsonResponse(serializer.data, safe=False)

    def get(self,request):
        """模型类序列化器的基本使用：反序列化验证数据"""
        # 模拟客户端提交过来的数据
        data = {
            "name": "hello",
            "classmate": 305,
            "age": 20,
            "description": "hello world",
            "password": "456",
            "re_password": "456",
        }
        serializer = StudentModelSerializer(data=data)
        print(serializer)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return JsonResponse(serializer.data, safe=False)