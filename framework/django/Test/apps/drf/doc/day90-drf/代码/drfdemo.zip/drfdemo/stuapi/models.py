from django.db import models


# Create your models here.
class Student(models.Model):
    """学生信息"""
    name = models.CharField(max_length=255, verbose_name="姓名", help_text="姓名")
    sex = models.BooleanField(default=True, verbose_name="性别" ,help_text="性别")
    age = models.IntegerField(verbose_name="年龄", help_text="年龄")
    classmate = models.CharField(db_column="class", max_length=5, verbose_name="班级", help_text="班级编号为3个数字组成")
    description = models.TextField(max_length=1000, null=True, blank=True, verbose_name="个性签名", help_text="个性签名")
    created_time = models.DateTimeField(auto_now_add=True, null=True, blank=True, help_text="注册日期")

    class Meta:
        db_table = "tb_student"
        verbose_name = "学生信息"
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.name

    """自定义方法字段"""
    # def sex_text(self):
    #     return "男" if self.sex else "女"
    #
    # # 自定义字段列的文本描述
    # sex_text.short_description = "性别"
    # sex_text.admin_order_field = "sex"
    #
    # def born(self):
    #     from datetime import datetime
    #     return datetime.now().year - self.age
    #
    # # 自定义字段列的文本描述
    # born.short_description = "出生年份"
    # born.admin_order_field = "age"