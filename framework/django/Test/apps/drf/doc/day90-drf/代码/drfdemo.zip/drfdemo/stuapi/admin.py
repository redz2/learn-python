from django.contrib import admin
from .models import Student

class StudentModelAdmin(admin.ModelAdmin):
    """列表页配置"""
    # 列表列显示的数据字段[值可以是模型的字段，也可以是模型的方法名（方法不能有参数）]
    list_display = ["id", "name", "classmate", "age", "sex", "sex_text", "born"]
    # 设置点击哪些字段可以跳转到详情页
    list_display_links = ["id"]

    # 默认排序[值只能是模型字段，不能是模型方法]
    ordering = ['-age','id']
    # 动作栏是否在上下方显示
    actions_on_top = True     # 上方控制栏是否显示,默认False表示隐藏
    actions_on_bottom = True  # 下方控制栏是否显示,默认False表示隐藏

    # 设置过滤器的字段条件[值只能是模型字段，不能是模型方法]
    list_filter = ["classmate", "sex"]  # 过滤器,按指定字段的不同值来进行展示

    # 允许直接点击列表页进入编辑的字段[值只能是模型字段，不能是模型方法]
    list_editable = ["age"]

    # 分页显示列表页数据[单页数据量]
    list_per_page = 5

    # 搜索框搜索字段条件[值只能是模型字段，不能是模型方法]
    search_fields = ["name", "classmate"]  # 搜索内容

    # 日期筛选功能[值只能是模型中的日期时间字段，不能是模型方法，也不能时其他格式字段]
    date_hierarchy = "created_time"

    # 自定义方法字段
    def sex_text(self, obj):
        return "男" if obj.sex else "女"

    # 自定义字段列的文本描述
    sex_text.short_description = "性别"
    sex_text.admin_order_field = "sex"

    @admin.display(description="出生年份", ordering="age")
    def born(self, obj):
        from datetime import datetime
        return datetime.now().year - obj.age


    """详情页配置"""
    # # 设置修改或添加页面的表单中显示的字段列表
    # fields = ['name', 'sex', 'age', 'classmate', "description"]

    # # 设置修改或添加页面的表单中不显示的字段列表
    # exclude = ["classmate"]

    # 字段分组展示,字段分组和上面的字段列表配置（fiedls或exclude）是互斥的。
    fieldsets = (
        ("必填项", {
            'fields': ('name', 'age', 'description')
        }),
        ('可选项', {
            'classes': ('collapse',),  # 折叠样式
            'fields': ('sex', 'classmate'),
        }),
    )

    # 添加数据的字段列配置
    add_fieldsets = (
        ("必填项", {
            'classes': ('wide',),
            'fields': ('name', 'age', 'classmate'),
        }),
        ('可选项', {
            'classes': ('collapse',),  # 折叠样式
            'fields': ('sex', 'description'),
        }),
    )


    # 识别当前操作是添加数据还是更新数据，方便加载不同的fieldsets配置
    def get_fieldsets(self, request, obj=None):
        """
        :request 本次客户端的请求处理对象
        :obj     本次客户端更新的模型对象[如果本次操作属于添加数据操作，则obj的值为None]
        """
        if obj:
            # 修改数据的操作
            return self.fieldsets
        # 添加数据的操作
        return self.add_fieldsets

    def save_model(self, request, obj, form, change):
        """
        当站点保存(添加、编辑)当前模型时自动执行的钩子方法
        区分：依靠ID来进行区分,obj是否有id
        :request 本次客户端的请求处理对象
        :obj     本次客户端操作的模型对象[如果本次操作属于添加数据操作，则obj的值为None]
        :form    本次客户端提交的表单信息
        :change  本次客户端更新数据后的表单信息
        """
        # 验证数据或者补充代码操作
        if obj.age > 100 or obj.age < 1:
            raise TypeError("年龄必须是正常人类的年龄！")

        if obj.id:
            print("更新模型操作")
        else:
            print("添加模型操作")

        return super().save_model(request, obj, form, change)  # 让当前模型继续保存数据,如果上面代码已经完成操作，这一句代码可以注释掉了。


    def delete_model(self, request, obj):
        """详情页删除操作"""
        print("详情页删除模型操作")
        return super().delete_model(request, obj)

    def delete_queryset(self, request, queryset):
        """列表页删除操作"""
        print("列表页删除模型操作")
        return super().delete_queryset(request, queryset)

admin.site.register(Student, StudentModelAdmin)


