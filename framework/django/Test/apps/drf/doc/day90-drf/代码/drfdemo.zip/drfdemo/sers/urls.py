from django.urls import path
from . import views
urlpatterns = [
    path("s1/", views.Student1View.as_view()),
]