

"""django的原生视图类"""
from django.views import View
from django.http.response import JsonResponse

class StudentView(View):
    def get(self, request):
        print(request)  # <WSGIRequest: GET '/req/s1'>  from django.core.handlers.wsgi import WSGIRequest
        return JsonResponse({"name":"django视图返回的xiaoming"})


"""drf提供的API视图类"""
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

class StudentAPIView(APIView):
    def get(self, request):
        print(request)  # <rest_framework.request.Request: GET '/req/s2'>
        print(request._request) # <WSGIRequest: GET '/req/s2'>
        """
        从上面可以看到，APIView类中提供的request对象是drf单独声明的，但是里面提供了_request属性的值是django视图类提供的request
        """
        print(request.query_params)
        # response = Response({"name": "xiaohong"}, headers={"company": "my company"})
        # print(response.data) # 响应体数据，渲染前的
        # print(response.status_code)  # 响应状态码
        # print(response.status_text)  # 响应状态信息
        # return response

        return Response(data=request.query_params, status=status.HTTP_201_CREATED)

    def post(self,request):
        """request提供了data属性，基于内容协商以统一的data属性来获取客户端以任何形式提交过来的数据"""
        print(request.data)
        # 如果客户端提交的是json数据，则request.data得到的数据是一个字典   {'name': 'xiaoming', 'age': 18, 'description': 'xxxxx'}
        # 如果客户端提交的是表单数据，则request.data得到的QueryDict类字典 <QueryDict: {'name': ['xiaohong'], 'age': ['20']}>
        print(request.query_params)
        return Response({"message": "ok"})