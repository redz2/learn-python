from rest_framework.viewsets import ModelViewSet
from .serializers import Student0ModelSerializer, Student


# Create your views here.
class StudentModelViewSet(ModelViewSet):
    queryset = Student.objects.all()
    serializer_class = Student0ModelSerializer
