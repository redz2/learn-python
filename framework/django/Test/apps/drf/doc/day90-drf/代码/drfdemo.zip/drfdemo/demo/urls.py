from django.urls import path,re_path
from . import views
urlpatterns = [
    # APIView
    path("students/", views.StudentAPIView.as_view()),
    re_path("^students/(?P<pk>\d+)/$", views.StudentInfoAPIView.as_view()),

    # GenericAPIView
    path("students1/", views.StudentGenericAPIView.as_view()),
    re_path("^students1/(?P<pk>\d+)/$", views.StudentInfoGenericAPIView.as_view()),

    # GenericAPIView + Mixins
    path("students2/", views.StudentListAPIView.as_view()),
    re_path("^students2/(?P<pk>\d+)/$", views.StudentRetrieveAPIView.as_view()),

    # 视图子类
    path("students3/", views.StuListAPIView.as_view()),
    re_path("^students3/(?P<pk>\d+)/$", views.StuRetrieveAPIView.as_view()),

    # ViewSet
    # 视图集的路由注册格式
    # path("访问路径", views.视图集类名.as_view({"http请求方法名": "视图方法名", "http请求方法名": "视图方法名", ...})),
    path("students4/", views.StudentViewSet.as_view({"get": "list", "post": "create"})),
    re_path("^students4/(?P<pk>\d+)/$", views.StudentViewSet.as_view({
        "get": "retrieve",
        "put": "update",
        "delete": "destroy",
    })),

    # GenericViewSet
    path("students5/", views.StudentGenericViewSet.as_view({"get": "list", "post": "create"})),
    re_path("^students5/(?P<pk>\d+)/$", views.StudentGenericViewSet.as_view({
        "get": "retrieve",
        "put": "update",
        "delete": "destroy",
    })),

    # GenericViewSet + 模型扩展类
    path("students6/", views.StudentGenViewSet.as_view({"get": "list", "post": "create"})),
    re_path("^students6/(?P<pk>\d+)/$", views.StudentGenViewSet.as_view({
        "get": "retrieve",
        "put": "update",
        "delete": "destroy",
    })),

    # ModelViewSet 模型视图集
    path("students7/", views.StudentModelViewSet.as_view({"get": "list", "post": "create"})),
    re_path("^students7/(?P<pk>\d+)/$", views.StudentModelViewSet.as_view({
        "get": "retrieve",
        "put": "update",
        "delete": "destroy",
    })),

    # ReadOnlyModelViewSet  只读视图集
    path("students8/", views.StudentReadOnlyModelViewSet.as_view({"get": "list"})),
    re_path("^students8/(?P<pk>\d+)/$", views.StudentReadOnlyModelViewSet.as_view({"get": "retrieve"})),

]

"""使用路由集给视图集生成url路由"""
from rest_framework.routers import DefaultRouter, SimpleRouter

# 实例化路由对象
router = SimpleRouter()
# 注册视图集[每次注册一个视图集类，就需要调用register]
router.register("students9", views.StuModelViewSet, basename="student9")
router.register("students10", views.StuModelViewSet, basename="students10")

# 所有被注册的实体集生成的路由信息，全部会被集中到router.urls路由列表中，所以我们要把urls拼接到urlpatterns
urlpatterns += router.urls
