from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from swagger_client.api.archives_api import ArchivesApi
from swagger_client.api.medical_records_api import MedicalRecordsApi
from swagger_client.api.test_record_api import TestRecordApi
from swagger_client.api.user_api import UserApi
