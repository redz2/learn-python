# User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | 用户ID | [optional] 
**username** | **str** | 账号 | 
**password** | **str** | 密码 | 
**name** | **str** | 姓名 | 
**department** | **str** | 科室 | 
**is_active** | **bool** | 用户状态 true-为启用 false-为禁用 | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


