from rest_framework.viewsets import ModelViewSet
from .serializers import StudentModelSerializer, Student


# Create your views here.
class StudentModelViewSet(ModelViewSet):
    queryset = Student.objects.all()
    serializer_class = StudentModelSerializer
